import { environment } from "../../environments/environment";

export const API_DATE_FORMAT = 'DD-MM-YYYY HH:mm:ss';
export const apiServerUrl = `${environment.host}`;

export enum API_ROUTES {
    PLACE_BID = 'place-bid',
    ADD_ASSET = 'add-asset',
    TOKENS = 'tokens',
    USER = 'user',
    ASSET = "assets"
}
