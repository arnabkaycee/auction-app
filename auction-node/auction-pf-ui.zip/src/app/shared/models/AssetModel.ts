import { UserModel } from "./UserModel";

export class AssetModel {
    assetId?: string;
    owner?: UserModel;
    name?: string;
    description?: string;
    price?: Number;
    bidStart?: string;
    bidEnd?: string;
    isSold?: boolean;

}
