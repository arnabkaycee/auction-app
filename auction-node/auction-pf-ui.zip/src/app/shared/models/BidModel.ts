import { AssetModel } from "./AssetModel";

export class BidModel {
    bidId?: string;
    asset?: AssetModel;
    bidAmount?: Number;
    bidTime?: string;
}
