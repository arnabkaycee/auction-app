export class UserModel {
    userId?: string;
    email?: string;
    phone?: string;
    balance?: Number;
    org?: string;
}
