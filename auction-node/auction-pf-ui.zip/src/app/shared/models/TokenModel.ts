import { UserModel } from "./UserModel";

export class TokenModel {
    tokenId?: string;
    user?: UserModel;
}
