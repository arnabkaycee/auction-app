import { TestBed, inject } from '@angular/core/testing';

import { SharedAssetService } from './shared-asset.service';

describe('SharedAssetService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SharedAssetService]
    });
  });

  it('should be created', inject([SharedAssetService], (service: SharedAssetService) => {
    expect(service).toBeTruthy();
  }));
});
