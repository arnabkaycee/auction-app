import { Injectable } from '@angular/core';
import { LayoutModule } from '../../layout/layout.module';
import { ApiService } from './api.service';
import * as moment from 'moment';
import * as url from 'url';
import * as constants from '../../constants/app.constants';
import { BidModel } from '../models/BidModel';


@Injectable()
export class BidServiceService {

  constructor(
    private apiService: ApiService,
  ) { }

  placeBid(bidObject: BidModel) {
    const time = moment().toISOString();
    bidObject.bidTime = time;
    const apiURL = url.resolve(constants.apiServerUrl, constants.API_ROUTES.PLACE_BID);
    return this.apiService.post(apiURL, bidObject);
  }

}
