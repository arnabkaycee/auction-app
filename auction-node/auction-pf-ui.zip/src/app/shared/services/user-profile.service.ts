import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import * as moment from 'moment';
import * as url from 'url';
import * as constants from '../../constants/app.constants';
import { LayoutModule } from '../../layout/layout.module';
import { Observable } from 'rxjs';
import { TokenModel } from '../models/TokenModel';
import { UserModel } from '../models/UserModel';

@Injectable()
export class UserProfileService {

  constructor(
    private apiService: ApiService,
  ) { }

  getTokens(): Observable<TokenModel[]> {
    const apiURL = url.resolve(constants.apiServerUrl, constants.API_ROUTES.TOKENS);
    return this.apiService.get(apiURL);
  }

  getCurrentUser(): Observable<UserModel> {
    const apiURL = url.resolve(constants.apiServerUrl, constants.API_ROUTES.USER);
    return this.apiService.get(apiURL);
  }

}
