import { Injectable } from '@angular/core';
import { AssetModel } from '../models/AssetModel';

@Injectable()
export class SharedAssetService {

  asset: AssetModel;
  constructor() { }

  setAsset(asset: AssetModel) {
    this.asset = asset;
  }

  getAsset() {
    return this.asset;
  }
}
