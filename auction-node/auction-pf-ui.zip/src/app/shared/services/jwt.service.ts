import { Injectable } from '@angular/core';
import { TokenModel } from '../models/TokenModel';

@Injectable()
export class JwtService {

  token: TokenModel;

  constructor() { }

  destroyToken() {
    window.localStorage.removeItem('jwtToken');
  }

  setTokenModel(tokenObj: TokenModel) {
    this.token = tokenObj;
    window.localStorage['jwtToken'] = this.token.tokenId;
  }

  getTokenModel(): TokenModel {
    return this.token;
  }
  getToken(): string {
    return (this.token && this.token.tokenId) ? this.token.tokenId : "";
  }

}
