import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

import { Observable, of } from 'rxjs';
import { JwtService } from './jwt.service';

@Injectable()
export class ApiService {
  constructor(
    private http: HttpClient,
    private jwtTokenService: JwtService
  ) { }

  private getHeaders(headersConfig?: object): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.jwtTokenService.getToken(),
      ...headersConfig,
    });
  }

  private formatErrors(error: any) {
    return Observable.throw(error);
  }

  get(url: string, params: HttpParams = new HttpParams()): Observable<any> {
    return this.http.get(
      url,
      { headers: this.getHeaders(), params }
    ).pipe(catchError(this.handleError('Get request')));
  }

  put(url: string, body: Object = {}): Observable<any> {
    return this.http.put(
      url,
      body,
      { headers: this.getHeaders() }
    ).pipe(catchError(this.handleError<any>('put request')));
  }

  post(url: string, body: Object = {}): Observable<any> {
    return this.http.post(
      url,
      body,
      { headers: this.getHeaders() }
    ).pipe(catchError(this.handleError<any>('post request')));
  }

  /**
 * Handle Http operation that failed.
 * Let the app continue.
 * @param operation - name of the operation that failed
 * @param result - optional value to return as the observable result
 */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      //this.logger.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      //this.logger.error(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
