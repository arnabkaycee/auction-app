import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import * as url from 'url';
import * as constants from '../../constants/app.constants';
import { Observable } from 'rxjs';
import { AssetModel } from '../models/AssetModel';

@Injectable()
export class AssetService {

  constructor(
    private apiService: ApiService,
  ) { }

  getAllAssets(): Observable<AssetModel[]> {
    const apiURL = url.resolve(constants.apiServerUrl, constants.API_ROUTES.ASSET);
    return this.apiService.get(apiURL);
  }

  addAsset(assetObject: AssetModel) {
    const apiURL = url.resolve(constants.apiServerUrl, constants.API_ROUTES.ADD_ASSET);
    return this.apiService.post(apiURL, assetObject);
  }

}
