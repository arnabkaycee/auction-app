import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';
import { ShowAssetsComponent } from './components/show-assets/show-assets.component';
import { PlaceBidComponent } from './components/place-bid/place-bid.component';
import { AddAssetComponent } from './components/add-asset/add-asset.component';
import { ViewOwnedAssetsComponent } from './components/view-owned-assets/view-owned-assets.component';
import { LandingPageComponent } from './components/landing-page/landing-page.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            { path: '', component: LandingPageComponent },
            { path: 'show-assets', component: ShowAssetsComponent },
            { path: 'place-bid', component: PlaceBidComponent },
            { path: 'add-asset', component: AddAssetComponent },
            { path: 'view-owned-assets', component: ViewOwnedAssetsComponent }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule { }
