import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserModel } from '../../../shared/models/UserModel';
import { UserProfileService } from '../../../shared/services/user-profile.service';
import { AssetModel } from '../../../shared/models/AssetModel';
import { SharedAssetService } from '../../../shared/services/shared-asset.service';
import * as moment from 'moment';
import * as constants from '../../../constants/app.constants';
import { BidServiceService } from '../../../shared/services/bid-service.service';
import { BidModel } from '../../../shared/models/BidModel';

@Component({
  selector: 'app-place-bid',
  templateUrl: './place-bid.component.html',
  styleUrls: ['./place-bid.component.scss']
})
export class PlaceBidComponent implements OnInit {

  constructor(
    private route: ActivatedRoute,
    private userService: UserProfileService,
    private sharedAsset: SharedAssetService,
    private bidService: BidServiceService) {
    this.bid = new BidModel();
  }

  assetId: string;
  user: UserModel;
  asset: AssetModel;
  bid: BidModel;

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.assetId = params['id'];
      this.asset = this.sharedAsset.getAsset();
      this.setDates();
    });
    this.userService.getCurrentUser().subscribe(data => this.user = data);
  }

  setDates() {
    let startDate = moment().add(15, 'minutes');
    let endDate = startDate.clone().add(1, 'day');
    this.asset.bidStart = startDate.format(constants.API_DATE_FORMAT);
    this.asset.bidEnd = endDate.format(constants.API_DATE_FORMAT);
  }

  placeBid() {
    //this.bid = new BidModel();
    let assetId = this.asset.assetId;
    let assetOwnerEmail = this.asset.owner.email;
    this.bid.asset = new AssetModel();
    this.bid.asset.assetId = assetId;
    this.bid.asset.owner = new UserModel();
    this.bid.asset.owner.email = assetOwnerEmail;
    this.bid.bidId = "BID_" + new Date().getTime().toString();
    this.bidService.placeBid(this.bid).subscribe(data => alert("Placed bid with txId : "+data));
  }

}
