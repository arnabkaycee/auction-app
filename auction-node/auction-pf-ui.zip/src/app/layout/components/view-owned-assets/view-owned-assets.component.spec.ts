import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewOwnedAssetsComponent } from './view-owned-assets.component';

describe('ViewOwnedAssetsComponent', () => {
  let component: ViewOwnedAssetsComponent;
  let fixture: ComponentFixture<ViewOwnedAssetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewOwnedAssetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewOwnedAssetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
