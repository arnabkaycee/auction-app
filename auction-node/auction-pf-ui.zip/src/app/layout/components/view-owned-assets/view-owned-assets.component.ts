import { Component, OnInit } from '@angular/core';
import { AssetService } from '../../../shared/services/asset.service';
import { AssetModel } from '../../../shared/models/AssetModel';
import { JwtService } from '../../../shared/services/jwt.service';

@Component({
  selector: 'app-view-owned-assets',
  templateUrl: './view-owned-assets.component.html',
  styleUrls: ['./view-owned-assets.component.scss']
})
export class ViewOwnedAssetsComponent implements OnInit {

  assets: AssetModel[];

  constructor(
    private assetService: AssetService,
    private jwtService: JwtService,
  ) { }

  ngOnInit() {
    this.getAssets()
  }
  getAssets() {
    let myEmail = this.jwtService.getTokenModel().user.email;
    this.assetService.getAllAssets().subscribe(data => {
      this.assets = data.filter(asset => asset.owner.email == myEmail);
    });

  }
}
