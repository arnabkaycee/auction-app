import { Component, OnInit, AfterViewInit } from '@angular/core';
import { AssetModel } from '../../../shared/models/AssetModel';
import { UserModel } from '../../../shared/models/UserModel';
import { JwtService } from '../../../shared/services/jwt.service';
import { TokenModel } from '../../../shared/models/TokenModel';
import { UserProfileService } from '../../../shared/services/user-profile.service';
import * as moment from 'moment';
import * as constants from '../../../constants/app.constants';
import { AssetService } from '../../../shared/services/asset.service';

@Component({
  selector: 'app-add-asset',
  templateUrl: './add-asset.component.html',
  styleUrls: ['./add-asset.component.scss']
})
export class AddAssetComponent implements OnInit {

  asset: AssetModel;

  constructor(private jwtService: JwtService, private userService: UserProfileService, private assetService: AssetService) {
    this.asset = new AssetModel();
    this.asset.owner = new UserModel();
  }

  ngOnInit() {
    this.userService.getCurrentUser().subscribe(data => this.asset.owner = data);
    this.setDates();
  }

  setDates() {
    let startDate = moment().add(15, 'minutes');
    let endDate = startDate.clone().add(1, 'day');

    this.asset.bidStart = startDate.format(constants.API_DATE_FORMAT);
    this.asset.bidEnd = endDate.format(constants.API_DATE_FORMAT);
  }

  parseAndSetDates(assetObj: AssetModel): AssetModel {
    assetObj.bidStart = moment(assetObj.bidStart, constants.API_DATE_FORMAT).toISOString();
    assetObj.bidEnd = moment(assetObj.bidEnd, constants.API_DATE_FORMAT).toISOString();
    return assetObj;
  }

  addAsset() {
    let assetObj = Object.assign({}, this.asset);
    let assetOwnerEmail = assetObj.owner.email;
    assetObj.owner = new UserModel();
    assetObj.owner.email = assetOwnerEmail;
    assetObj = this.parseAndSetDates(assetObj);
    this.assetService.addAsset(assetObj).subscribe(data => alert("Added Asset with txId:" + data));
  }


}
