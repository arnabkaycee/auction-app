import { Component, OnInit } from '@angular/core';
import { AssetModel } from '../../../shared/models/AssetModel';
import { AssetService } from '../../../shared/services/asset.service';
import * as moment from 'moment';
import * as constants from '../../../constants/app.constants';
import { JwtService } from '../../../shared/services/jwt.service';
import { Router } from '@angular/router';
import { SharedAssetService } from '../../../shared/services/shared-asset.service';

@Component({
  selector: 'app-show-assets',
  templateUrl: './show-assets.component.html',
  styleUrls: ['./show-assets.component.scss']
})
export class ShowAssetsComponent implements OnInit {

  assets: AssetModel[];

  constructor(
    private assetService: AssetService,
    private jwtService: JwtService,
    private router: Router,
    private sharedAsset: SharedAssetService
  ) { }

  ngOnInit() {
    this.getAssets()
  }
  getAssets() {
    this.assetService.getAllAssets().subscribe(data => this.assets = data);
  }

  isBidDisabled(asset: AssetModel) {
    let startDate = moment(asset.bidStart);
    let endDate = moment(asset.bidEnd);
    let now = moment();
    return now.isAfter(endDate) || now.isBefore(startDate);
  }

  placeBid(asset: AssetModel) {
    this.sharedAsset.setAsset(asset);
    this.router.navigate(['place-bid', { 'asset': asset.assetId }]);
  }
  isAssetBelongsToOwner(asset: AssetModel) {
    return this.jwtService.token.user.email != asset.owner.email;
  }

}
