import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { NgbDropdownModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { LayoutRoutingModule } from './layout-routing.module';
import { LayoutComponent } from './layout.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { HeaderComponent } from './components/header/header.component';
import { ShowAssetsComponent } from './components/show-assets/show-assets.component';
import { PlaceBidComponent } from './components/place-bid/place-bid.component';
import { AddAssetComponent } from './components/add-asset/add-asset.component';
import { ViewOwnedAssetsComponent } from './components/view-owned-assets/view-owned-assets.component';
import { BidServiceService } from '../shared/services/bid-service.service';
import { UserProfileService } from '../shared/services/user-profile.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AssetService } from '../shared/services/asset.service';
import { LandingPageComponent } from './components/landing-page/landing-page.component';
import { SharedAssetService } from '../shared/services/shared-asset.service';

@NgModule({
    imports: [
        CommonModule,
        LayoutRoutingModule,
        TranslateModule,
        NgbDropdownModule.forRoot(),
        NgbModule.forRoot(),
        FormsModule
    ],
    declarations: [LayoutComponent, SidebarComponent, HeaderComponent, ShowAssetsComponent, PlaceBidComponent, AddAssetComponent, ViewOwnedAssetsComponent, LandingPageComponent],
    providers: [BidServiceService, UserProfileService, AssetService, SharedAssetService]
})
export class LayoutModule { }
